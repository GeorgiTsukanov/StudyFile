package Computational_methods;

public class Main {
    public static void main(String[] args){
        ex1();
    }

    public static void ex1(){
        double [][]m = new double[][] {
                {2, 2},
                {3, 4}
        };

        double []v = new double[]{2, 5};

        double []V = MyMath.Gauss(m, v);
        for (int i=0; i<V.length; i++){
            System.out.println(V[i]);
        }
    }

    public static void ex2(){
        double [][]m = new double[][] {
                {2, 2},
                {3, 4}
        };

        System.out.println(MyMath.det(m));
    }

    public static void ex3(){
        double [][]m = new double[][] {
                {2, 2},
                {3, 4}
        };

        double [][]mi = MyMath.inverse(m);

        for (int i=0; i < mi.length; i++, System.out.print("\n")){
            for (int j=0; j < mi.length; j++){
                System.out.print(mi[i][j] + " ");
            }
        }
    }
}
