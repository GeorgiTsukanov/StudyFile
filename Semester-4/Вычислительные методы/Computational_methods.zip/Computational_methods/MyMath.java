package Computational_methods;

public class MyMath {
    public static double[] Gauss(double[][] m, double[] v){

        double[][] A = m.clone();
        double[] B = v.clone();

        for (int i = 0; i < B.length; i++) {
            for (int k = i + 1; k < B.length; k++) {
                double f = A[k][i] / A[i][i];
                for (int j = i; j < B.length; j++) {
                    A[k][j] -= f * A[i][j];
                }
                B[k] -= f * B[i];
            }
        }

        /*
        double[] X = new double[B.length];
        for (int i = B.length - 1; i >= 0; i--) {
            double sum = B[i];
            for (int j = i + 1; j < B.length; j++) {
                sum -= A[i][j] * X[j];
            }
            X[i] = sum / A[i][i];
        }
        return X;
        */

        for (int i = B.length - 1; i >= 0; i--) {
            for (int k = i - 1; k >= 0; k--) {
                double f = A[k][i] / A[i][i];
                for (int j = 0; j < B.length; j++) {
                    A[k][j] -= f * A[i][j];
                }
                B[k] -= f * B[i];
            }
        }

        double[] V = new double[B.length];
        for (int i=0; i < B.length; i++){
            V[i] = B[i] / A[i][i];
        }
        return V;
    }

    public static double det(double[][] m){
        double[][] A = m.clone();
        for (int i = 0; i < A.length; i++) {
            for (int k = i + 1; k < A.length; k++) {
                double f = A[k][i] / A[i][i];
                for (int j = i; j < A.length; j++) {
                    A[k][j] -= f * A[i][j];
                }
            }
        }

        double det = 1;
        for (int i=0; i<A.length; i++){
            det *= A[i][i];
        }
        return det;
    }

    public static double[][] inverse(double[][] m){
        double[][] A = m.clone();
        double[][] Ai = new double[A.length][A.length];
        for (int i = 0; i < A.length; i++){
            Ai[i][i] = 1;
        }

        for (int i = 0; i < A.length; i++) {
            for (int k = i + 1; k < A.length; k++) {
                double f = A[k][i] / A[i][i];
                for (int j = i; j < A.length; j++) {
                    A[k][j] -= f * A[i][j];
                    Ai[k][j] -= f * Ai[i][j];
                }
            }
        }

        for (int i = A.length - 1; i >= 0; i--) {
            for (int k = i - 1; k >= 0; k--) {
                double f = A[k][i] / A[i][i];
                for (int j = 0; j < A.length; j++) {
                    A[k][j] -= f * A[i][j];
                    Ai[k][j] -= f * Ai[i][j];
                }
            }
        }

        for (int i=0; i<A.length; i++){
            for (int j=0; j<A.length; j++){
                Ai[i][j] /= A[i][i];
            }
        }
        return Ai;
    }
}
