package Ex1;

public class MyMath {
    public static Matrix inverse(Matrix m) throws IllegalArgumentException{
        if (m.getM().length != m.getM()[0].length) {
            throw new IllegalArgumentException("Матрица должна быть квадратной");
        }
        if (det(m) == 0){
            throw new IllegalArgumentException("Определитель матрицы равени нулю. Матрица необратима");
        }

        double[][] A = m.getM().clone();
        double[][] Ai = new double[A.length][A.length];
        for (int i = 0; i < A.length; i++){
            Ai[i][i] = 1;
        }

        for (int i = 0; i < A.length; i++) {
            for (int k = i + 1; k < A.length; k++) {
                double f = A[k][i] / A[i][i];
                for (int j = i; j < A.length; j++) {
                    A[k][j] -= f * A[i][j];
                    Ai[k][j] -= f * Ai[i][j];
                }
            }
        }

        for (int i = A.length - 1; i >= 0; i--) {
            for (int k = i - 1; k >= 0; k--) {
                double f = A[k][i] / A[i][i];
                for (int j = 0; j < A.length; j++) {
                    A[k][j] -= f * A[i][j];
                    Ai[k][j] -= f * Ai[i][j];
                }
            }
        }

        for (int i=0; i<A.length; i++){
            for (int j=0; j<A.length; j++){
                Ai[i][j] /= A[i][i];
            }
        }
        return new Matrix(Ai);
    }

    public static  double det(Matrix m){
        double[][] A = m.getM().clone();
        for (int i = 0; i < A.length; i++) {
            for (int k = i + 1; k < A.length; k++) {
                double f = A[k][i] / A[i][i];
                for (int j = i; j < A.length; j++) {
                    A[k][j] -= f * A[i][j];
                }
            }
        }

        double det = 1;
        for (int i=0; i<A.length; i++){
            det *= A[i][i];
        }
        return det;
    }
}
