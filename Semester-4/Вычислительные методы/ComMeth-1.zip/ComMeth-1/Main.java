package Ex1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        S();
        MatrixSerializer.getMatrix(1, "Data/M.bin").print();
        MatrixSerializer.getMatrix(1, "Data/reverseM.bin").print();
    }

    public static void S(){
        Matrix[] m = new Matrix[]{
                new Matrix(new double[][]{
                        {1, 1},
                        {3, 2}
                }),
                new Matrix(new double[][]{
                        {2, 1},
                        {7, 5}
                }),
                new Matrix(new double[][]{
                        {2, 2, 4},
                        {3, 7, 4},
                        {2, 2, 2}
                }),
        };

        for (Matrix i: m){
            MatrixSerializer.saveMatrix(i, "Data/M.bin");
            MatrixSerializer.saveMatrix(MyMath.inverse(i), "Data/reverseM.bin");
        }
    }

}
