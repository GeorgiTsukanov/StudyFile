package Ex1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MatrixSerializer {
    public static void saveMatrix(Matrix matrix, String path) {
        List<Matrix> matrices = new ArrayList<>();

        File file = new File(path);
        if (file.exists()) {
            matrices = readAllMatrices(path);
        }

        matrices.add(matrix);
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path))) {
            out.writeObject(matrices);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static Matrix getMatrix(int index, String path) {
        List<Matrix> matrices = readAllMatrices(path);
        if (index >= 0 && index < matrices.size()) {
            return matrices.get(index);
        } else {
            throw new IndexOutOfBoundsException("Индекс выходит за границы сохранённых матриц.");
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Matrix> readAllMatrices(String path) {
        File file = new File(path);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(path))) {
            return (List<Matrix>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
            return new ArrayList<>();
        }
    }
}
