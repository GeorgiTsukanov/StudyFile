package Ex1;

import java.io.Serializable;

public class Matrix implements Serializable{
    double [][]m;
    public Matrix(double[][] m){
        this.m = m;
    }

    public double[][] getM() {
        return m;
    }

    public void print(){
        for (double[] i: m){
            System.out.println(" ");
            for (double j: i){
                System.out.print(j + " ");
            }
        }
    }

}
